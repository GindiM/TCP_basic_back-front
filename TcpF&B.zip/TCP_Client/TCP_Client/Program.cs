﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;


string host = "192.168.1.12";
//string host = "localhost";
int port = 10001;

TcpClient client = new TcpClient(host, port);
NetworkStream stream = client.GetStream();

Thread thread = new Thread(writeToStream);
thread.Start();

while (true)
{
    // Wait a sec/2 - avoid memory run out.
    System.Threading.Thread.Sleep(500);

    // recieve
    if (stream.DataAvailable)
    {
        byte[] buffer = new byte[2048];
        int a = stream.Read(buffer, 0, buffer.Length);
        Console.WriteLine((Encoding.UTF8.GetString(buffer)));
        stream.Flush();
    }
    //Thread thread = new Thread(writeToStream);
    //thread.Start();

}
void writeToStream()
{
    while (true)
    {
        string message = Console.ReadLine();
        if (message != null && message.Length > 0)
        {
            byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            stream.Write(data, 0, data.Length);
            stream.Flush(); //warning! might flush incoming data

        }


    }
    thread.Start();
}

